# Lab 6 – Notes  

- **Proxy Setup:** Added Vite dev proxy so `/api/...` calls work without CORS issues. Much cleaner than enabling backend CORS.  
- **Fetch Helper:** Central `request<T>` function simplified API calls and standardized error handling.  
- **UI Components:** `ExpensesList` + `AddExpenseForm` stayed minimal by relying on the `api` layer.  
- **Refresh Key:** Used a simple `refreshKey` to reload data; works now but will be replaced with TanStack Query.  
