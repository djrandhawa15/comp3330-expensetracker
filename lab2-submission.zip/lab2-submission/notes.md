- I learned how to get api arrays
- I also learned how to get the response times and how to test endpoints
- I liked how to use localhost and i also learned how to create routers
Git repo
    -https://github.com/djrandhawa15/comp3330-expensetracker