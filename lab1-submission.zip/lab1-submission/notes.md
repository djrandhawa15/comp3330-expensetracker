- I learned how to use thunder client
- I also learned how to use API and how hono works
- I liked how to use localhost
Git repo
    -https://github.com/djrandhawa15/comp3330-expensetracker